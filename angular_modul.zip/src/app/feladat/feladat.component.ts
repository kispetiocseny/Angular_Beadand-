import { Component } from '@angular/core';

@Component({
  selector: 'app-feladat',
  templateUrl: './feladat.component.html',
  styleUrls: ['./feladat.component.css']
})
export class FeladatComponent {
  szam: number = 1;
  
  PrimE(szam: number): boolean {
    if (szam < 2) {
      return false;
    }

    for (let i: number = 2; i <= Math.sqrt(szam); i++) {
      if (szam % i == 0) {
        return false;
      }
    }

    return true;
  }

  eredmenyek: string[] = [];

  eredmenyMentes(): void {
    if (this.PrimE(this.szam)) {
      this.eredmenyek.push("A(z) " + this.szam + " prím.");
    } else {
      this.eredmenyek.push("A(z) " + this.szam + " nem prím.");
    }
  }
}
